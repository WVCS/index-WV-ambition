#4D4DFF - neon blue
#C8A2C8 - lilac